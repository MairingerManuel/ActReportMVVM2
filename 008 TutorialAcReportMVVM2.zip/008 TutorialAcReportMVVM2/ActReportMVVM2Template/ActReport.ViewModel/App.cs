﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace ActReport.ViewModel
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            IController controller = new MainController();
            controller.ShowWindow(new EmployeeViewModel(controller));
        }
    }
}
